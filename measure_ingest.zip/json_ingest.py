import csv
import boto3
import os
import logging
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)
s3 = boto3.client('s3')
RAW_BUCKET = os.environ["S3_RAW_BUCKET"]

# List objects in the specified S3 bucket
def lambda_handler(event, context):
    bucket_name = RAW_BUCKET
    prefix = "uploads/hist/"

    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)

    for obj in response.get('Contents', []):
        logger.info(f"Found object: {obj['Key']}")
        logger.info(f"Listing from bucket: {bucket_name} with prefix: {prefix}")

    return {"statusCode": 200, "body": "Listed files successfully"}
